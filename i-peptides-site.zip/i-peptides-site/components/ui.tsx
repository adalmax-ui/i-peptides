import Link from "next/link";
import { clsx } from "clsx";

export function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-slate-200 bg-white/70 px-2.5 py-1 text-xs text-slate-700">
      {children}
    </span>
  );
}

export function Button(props: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "solid" | "ghost" }) {
  const { className, variant = "solid", ...rest } = props;
  return (
    <button
      className={clsx(
        "inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-medium transition",
        variant === "solid" &&
          "bg-blue-600 text-white hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-600/60",
        variant === "ghost" &&
          "bg-transparent text-slate-800 hover:bg-white/60 border border-slate-200",
        className
      )}
      {...rest}
    />
  );
}

export function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-white/60 hover:text-slate-900">
      {children}
    </Link>
  );
}
